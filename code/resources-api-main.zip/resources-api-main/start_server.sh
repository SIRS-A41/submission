#!/bin/bash

# Start HTTP serverr
echo "Starting HTTP resources API server"
dart bin/resources_api.dart
